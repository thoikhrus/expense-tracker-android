package com.puiaxyz.expense;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import android.widget.SearchView;

public class MainActivity extends AppCompatActivity implements AddEditExpenseDialog.OnExpenseSavedListener {

    private RecyclerView recyclerView;
    private ExpenseAdapter adapter;
    private ExpenseDatabaseHelper dbHelper;
    private List<Expense> expenseList;
    private Button btnAddExpense;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new ExpenseDatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        btnAddExpense = findViewById(R.id.btnAddExpense);
        searchView = findViewById(R.id.searchView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadExpenses();

        btnAddExpense.setOnClickListener(v -> openAddDialog());

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return false;
            }
        });
    }

    private void loadExpenses() {
        expenseList = dbHelper.getAllExpenses();
        adapter = new ExpenseAdapter(expenseList, dbHelper, this);
        recyclerView.setAdapter(adapter);
    }

    private void openAddDialog() {
        AddEditExpenseDialog dialog = new AddEditExpenseDialog(null, dbHelper, this);
        dialog.show(getSupportFragmentManager(), "AddExpenseDialog");
    }

    @Override
    public void onExpenseSaved() {
        loadExpenses();
    }
}
