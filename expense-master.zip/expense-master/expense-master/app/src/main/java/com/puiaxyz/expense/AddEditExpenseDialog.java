package com.puiaxyz.expense;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddEditExpenseDialog extends DialogFragment {

    private EditText editTextName, editTextAmount;
    private Spinner spinnerCategory;
    private Button btnSave;
    private ExpenseDatabaseHelper dbHelper;
    private Expense expense;
    private OnExpenseSavedListener listener;

    private String[] categories = {"Food", "Transport", "Entertainment", "Other"};

    public AddEditExpenseDialog(Expense expense, ExpenseDatabaseHelper dbHelper, OnExpenseSavedListener listener) {
        this.expense = expense;
        this.dbHelper = dbHelper;
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_add_edit_expense, container, false);

        editTextName = view.findViewById(R.id.editTextName);
        spinnerCategory = view.findViewById(R.id.spinnerCategory);
        editTextAmount = view.findViewById(R.id.editTextAmount);
        btnSave = view.findViewById(R.id.btnSave);

        // Set up Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        if (expense != null) {
            editTextName.setText(expense.getName());
            editTextAmount.setText(String.valueOf(expense.getAmount()));

            // Set spinner selection to current category
            for (int i = 0; i < categories.length; i++) {
                if (categories[i].equals(expense.getCategory())) {
                    spinnerCategory.setSelection(i);
                    break;
                }
            }
        }

        btnSave.setOnClickListener(v -> {
            saveExpense();
        });

        return view;
    }

    private void saveExpense() {
        String name = editTextName.getText().toString();
        String category = spinnerCategory.getSelectedItem().toString();
        double amount = Double.parseDouble(editTextAmount.getText().toString());
        String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

        if (expense == null) {
            expense = new Expense(name, category, amount, dateTime);
            dbHelper.insertExpense(expense);
        } else {
            expense.setName(name);
            expense.setCategory(category);
            expense.setAmount(amount);
            expense.setDateTime(dateTime);
            dbHelper.updateExpense(expense);
        }

        listener.onExpenseSaved();
        dismiss();
    }

    public interface OnExpenseSavedListener {
        void onExpenseSaved();
    }
}

