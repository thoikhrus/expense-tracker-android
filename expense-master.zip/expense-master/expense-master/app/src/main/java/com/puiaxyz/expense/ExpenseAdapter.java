package com.puiaxyz.expense;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {

    private List<Expense> expenseList;
    private List<Expense> fullExpenseList;
    private ExpenseDatabaseHelper dbHelper;
    private AddEditExpenseDialog.OnExpenseSavedListener listener;

    public ExpenseAdapter(List<Expense> expenseList, ExpenseDatabaseHelper dbHelper, AddEditExpenseDialog.OnExpenseSavedListener listener) {
        this.expenseList = new ArrayList<>(expenseList);
        this.fullExpenseList = new ArrayList<>(expenseList);
        this.dbHelper = dbHelper;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_expense, parent, false);
        return new ExpenseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        Expense expense = expenseList.get(position);
        holder.textName.setText(expense.getName());
        holder.textCategory.setText(expense.getCategory());
        holder.textAmount.setText("₹" + expense.getAmount());
        holder.textDate.setText(expense.getDateTime());

        holder.itemView.setOnClickListener(v -> {
            AddEditExpenseDialog dialog = new AddEditExpenseDialog(expense, dbHelper, listener);
            dialog.show(((MainActivity) v.getContext()).getSupportFragmentManager(), "EditExpenseDialog");
        });

        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(v.getContext())
                    .setTitle("Delete Expense")
                    .setMessage("Are you sure you want to delete this expense?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // Fade-out animation
                        holder.itemView.animate()
                                .alpha(0f)
                                .setDuration(300) // Duration of fade-out (300ms)
                                .withEndAction(() -> {

                                    dbHelper.deleteExpense(expense.getId());
                                    expenseList.remove(position);
                                    fullExpenseList.remove(expense);
                                    notifyItemRemoved(position);
                                    Toast.makeText(v.getContext(), "Expense deleted", Toast.LENGTH_SHORT).show();
                                });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return expenseList.size();
    }

    public void filter(String text) {
        expenseList.clear();
        if (text.isEmpty()) {
            expenseList.addAll(fullExpenseList);
        } else {
            text = text.toLowerCase();
            for (Expense expense : fullExpenseList) {
                if (expense.getName().toLowerCase().contains(text) ||
                        expense.getCategory().toLowerCase().contains(text)) {
                    expenseList.add(expense);
                }
            }
        }
        notifyDataSetChanged();
    }

    public static class ExpenseViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textCategory, textAmount, textDate;

        public ExpenseViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textName);
            textCategory = itemView.findViewById(R.id.textCategory);
            textAmount = itemView.findViewById(R.id.textAmount);
            textDate = itemView.findViewById(R.id.textDate);
        }
    }
}
